package partie2;

import java.util.ArrayList;

public interface Critere {
    public Place getPlace(ArrayList<Place> places);
}
