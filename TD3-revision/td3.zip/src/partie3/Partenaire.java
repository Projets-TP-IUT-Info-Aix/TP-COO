package partie3;

public interface Partenaire {
    public void mettreAJour(String message, ObjetConnecte objet);
}
